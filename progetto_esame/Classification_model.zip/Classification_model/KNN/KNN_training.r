library(class)

# Importa il dataset MNIST
mnist_train <- read.csv("dataset\\Mnist_Train.csv")
mnist_test <- read.csv("dataset\\Mnist_Test.csv")

# Dividi i dataset in feature (X) e target (y)
X_train <- mnist_train[, -1]
y_train <- mnist_train[, 1]

X_test <- mnist_test[, -1]
y_test <- mnist_test[, 1]

# Imposta il numero di vicini (k)
k <- 5

# Applica KNN
predictions <- knn(train = X_train, test = X_test, cl = y_train, k = k)

print (predictions)
# Valuta le prestazioni
accuracy <- sum(predictions == y_test) / length(y_test)
cat("Accuracy del modello KNN:", accuracy, "\n")
