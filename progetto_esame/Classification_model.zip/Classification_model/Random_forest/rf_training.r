#Importing Library
library(caret)

#Importing Training & Testing Dataset
train_orig <- read.csv("dataset\\Mnist_Train.csv")
test_orig <- read.csv("dataset\\Mnist_Test.csv")

ncol_train <- ncol(train_orig)
ncol_test <- ncol(test_orig)

library(randomForest)

# Estrai le etichette dal dataframe di addestramento
train_orig_labels <- train_orig[, 1]

# Converte le etichette in un fattore
train_orig_labels <- as.factor(train_orig_labels)

# Rimuovi la colonna "label" dai dati di addestramento
train_data <- train_orig[, -1]

# Numero di alberi da costruire
num_trees <- 100

# Addestra il modello random forest
rf <- randomForest(x = train_data, y = train_orig_labels, ntree = num_trees)

saveRDS(rf, file = "randomForest.rds")