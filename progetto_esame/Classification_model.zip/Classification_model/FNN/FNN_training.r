library(nnet)

train_orig <- read.csv("dataset\\Mnist_Train.csv")
test_orig <- read.csv("dataset\\Mnist_Test.csv")

set.seed(123)
rows <- sample(seq_len(nrow(train_orig)), as.integer(0.7 * nrow(train_orig)))

train_labels <- as.factor(train_orig[rows, 1])
test_labels <- train_orig[-rows, 1]

# Estrai le etichette dal dataframe di addestramento
train_orig_labels <- train_orig[, 1]
# Converte le etichette in un fattore
train_orig_labels <- as.factor(train_orig_labels)

normalize <- function(x) {
  return(x / 255)
}

train_norm <- as.data.frame(lapply(train_orig[rows, -1], normalize))
test_norm <- as.data.frame(lapply(test_orig[-rows, -1], normalize))

train_labels_matrix <- class.ind(train_labels)

library(caret)
library(doParallel)

no_cores <- detectCores()
cl <- makeCluster(no_cores)

registerDoParallel(cl)

TrainingParameters <- trainControl(method = "cv", number = 3)

grid_nn <- expand.grid(.size = c(1, 3, 5, 10),
                       .decay = 0)

# use all of the given training data
train_norm <- as.data.frame(lapply(train_orig[, -1], normalize))

startTime <- proc.time()
set.seed(123)
nn2 <- train(train_norm, train_orig_labels,
             trControl = TrainingParameters,
             method = "nnet",
             tuneGrid = grid_nn,
             MaxNWts = 20000
            )

saveRDS(nn2, file = "neuralNetwork_nnet.rds")